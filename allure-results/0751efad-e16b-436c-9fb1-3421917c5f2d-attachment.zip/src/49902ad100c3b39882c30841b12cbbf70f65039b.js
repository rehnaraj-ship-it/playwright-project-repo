import{test,expect}from '@playwright/test'
import {LoginPage} from '../pages/loginPage'
test('verify login with valid credentials',async({page})=>{
    const loginpage=new LoginPage(page)
    await loginpage.openApplication()
    await loginpage.login()
    await expect(page).toHaveURL('https://www.saucedemo.com/inventory.html')
})