export class LoginPage
{
    constructor(page)
    {
        this.page=page
        this.username=page.locator('#user-name')
        this.password=page.locator('#password')
        this.loginButton=page.locator('login-button')
        this.errorMsg=page.locator('.error-message-container error')
    }
    async openApplication()
    {
        await this.page.goto('https://www.saucedemo.com/')
    }
    async login()
    {
        await this.username.fill('standard_user')
        await this.password.fill('secret_sauce')
        await this.loginButton.click()
    }
}