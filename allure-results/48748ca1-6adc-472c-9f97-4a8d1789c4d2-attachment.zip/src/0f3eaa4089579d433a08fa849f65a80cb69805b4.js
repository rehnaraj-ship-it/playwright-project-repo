import {test,expect}from '@playwright/test'
import { LoginPage } from '../pages/loginPage'
import validLogindata from '../utils/parameterizedTestdata.json'
for (const data of validLogindata ){
test(`login using valid credentials ${data['user-name']} ${data.password}`,async({page})=>{
    const lp = new LoginPage(page)
    await lp.openApplication() 
    await lp.login(data['user-name'],data.password)
    await expect(page).toHaveURL('https://www.saucedemo.com/inventory.html')
    await page.waitForTimeout(3000)
})}